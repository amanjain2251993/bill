<ul class="nav navbar-nav">
<li class="dropdown">
	<button class="btn btn-info dropdown-toggle" type="button" data-toggle="dropdown">Invoice
	<span class="caret"></span></button>
	<ul class="dropdown-menu">
		<li><a href="create_invoice.php">Create Invoice</a></li>

		<li><a href="invoice_list.php">Invoice List</a></li>		
	</ul>
</li>

</ul>
<br /><br /><br /><br />