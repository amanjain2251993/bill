<?php
session_start();
include 'Invoice.php';
$invoice = new Invoice();
//$invoice->checkLoggedIn();
if(!empty($_GET['invoice_id']) && $_GET['invoice_id'])  {
		echo $_GET['invoice_id'];
	$invoiceValues = $invoice->getInvoice($_GET['invoice_id']);		
	$invoiceItems = $invoice->getInvoiceItems($_GET['invoice_id']);	
}else{
	echo $_SESSION['order_id'];
	$invoiceValues = $invoice->getInvoice($_SESSION['order_id']);		
	$invoiceItems = $invoice->getInvoiceItems($_SESSION['order_id']);
}
unset($_SESSION['order_id']);
//$AmountInEnglish = $invoice->convert_to_words($invoiceValues['subtotal']);
//print_r($AmountInEnglish); die;
$invoiceDate = date("d/M/Y, H:i:s", strtotime($invoiceValues['order_date']));

$output = '';
$output .= '<table width="60%" border="1" cellpadding="5" cellspacing="0">	
	<tr>
	<div>
	<table width="100%" cellpadding="5">
	<tr>
	<td width="55%">
	To,<br />
	<b>Name : '.$invoiceValues['order_receiver_name'].'<br /><b> 
	</td>
	<td width="45%">         
	Invoice No. : '.$invoiceValues['order_id'].'<br />
	Invoice Date : '.$invoiceDate.'<br />
	</td>
	</tr>
	</table>
	<br />
	<table width="100%" border="1" cellpadding="5" cellspacing="0">
	<tr>
	<th align="left">Sr No.</th>
	<th align="left" width="35%">Item Name</th>
	<th align="left">Quantity</th>
	<th align="left">Price</th>
	<th align="left">Actual Amt.</th> 
	</tr>';
$count = 0;   
foreach($invoiceItems as $invoiceItem){
	$count++;
	$output .= '
	<tr>
	<td align="left">'.$count.'</td>
	<td align="left" width="35%">'.$invoiceItem["item_name"].'</td>
	<td align="left">'.$invoiceItem["order_item_quantity"].'</td>
	<td align="left">'.$invoiceItem["order_item_price"].'</td>
	<td align="left">'.$invoiceItem["order_item_final_amount"].'</td>   
	</tr>';
}
$output .= '
	<tr>
	<td colspan="4" align="right"><b>Sub Total</b></td>
	<td colspan="1" align="left"><b>'.$invoiceValues['subtotal'].'/-</b></td>
	</tr>'
	;
$output .= '
	</table>
	</div>
	</tr>
	</table>';
	$output .= '<script type="text/php">
        if ( isset($pdf) ) {
            // OLD 
            // $font = Font_Metrics::get_font("helvetica", "bold");
            // $pdf->page_text(72, 18, "{PAGE_NUM} of {PAGE_COUNT}", $font, 6, array(255,0,0));
            // v.0.7.0 and greater
            $x = 18;
            $y = 18;
            $text = "Page {PAGE_NUM} of {PAGE_COUNT}";
            $font = $fontMetrics->get_font("helvetica", "bold");
            $size = 6;
            $color = array(255,0,0);
            $word_space = 0.0;  //  default
            $char_space = 0.0;  //  default
            $angle = 0.0;   //  default
            $pdf->page_text($x, $y, $text, $font, $size, $color, $word_space, $char_space, $angle);
        }
    </script>';
	
	/* $temp = tmpfile();
	file_put_contents('index.html',$output);
	fclose($temp); */
// create pdf of invoice	
$invoiceFileName = 'Invoice-'.$invoiceValues['order_id'].'.pdf';
require_once 'dompdf/src/Autoloader.php';
Dompdf\Autoloader::register();
use Dompdf\Dompdf;


$dompdf = new Dompdf();

$dompdf->set_option('enable_remote', TRUE);
$dompdf->set_option("isPhpEnabled", true);


$output = html_entity_decode($output);
//$dompdf->load_html_file('http://localhost/Billing/index.html');
$dompdf->loadHtml($output);
//$dompdf->setPaper('A4', 'landscape');
$dompdf->setPaper('A5', 'portrait');
$dompdf->render();
$dompdf->stream($invoiceFileName, array("Attachment" => false));
?>   
   