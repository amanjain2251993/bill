 $(document).ready(function(){
	$(document).on('click', '#checkAll', function() {          	
		$(".itemRow").prop("checked", this.checked);
	});	
	$(document).on('click', '.itemRow', function() {  	
		if ($('.itemRow:checked').length == $('.itemRow').length) {
			$('#checkAll').prop('checked', true);
		} else {
			$('#checkAll').prop('checked', false);
		}
	});  
	var count = 3;
	$(document).on('click', '#addRows', function() { 
	for (i = 0; i < 5; i++) {
		
		var htmlRows = '';
		htmlRows += '<tr>';  
		htmlRows += '<td><input class="itemRow" type="checkbox"></td>';   
		htmlRows += '<td class="counterCell"></td>';          
		htmlRows += '<td><input type="text" name="productName[]" id="productName_'+count+'" class="form-control"></td>';	
		htmlRows += '<td><input type="number" name="quantity[]" step=".01" id="quantity_'+count+'" class="form-control quantity" autocomplete="off"></td>';   		
		htmlRows += '<td><input type="number" name="price[]" step=".01" id="price_'+count+'" class="form-control price" autocomplete="off"></td>';		 
		htmlRows += '<td><input type="number" name="total[]" id="total_'+count+'" class="form-control total" autocomplete="off" readonly></td>';          
		htmlRows += '<td><input  type="button" value="add" id="addRowsPerticular"/> </td>';          
		htmlRows += '</tr>';
		$('#invoiceItem').append(htmlRows);
		count++;
	}}); 
	$(document).on('click', '#addRowsPerticular', function() {
   var id  = $(this).closest('td').parent()[0].sectionRowIndex;
   var htmlRows = '';
		htmlRows += '<tr>';  
		htmlRows += '<td><input class="itemRow" type="checkbox"></td>';   
		htmlRows += '<td class="counterCell"></td>';          
		htmlRows += '<td><input type="text" name="productName[]" id="productName_'+count+'" class="form-control"></td>';	
		htmlRows += '<td><input type="number" name="quantity[]" step=".01" id="quantity_'+count+'" class="form-control quantity" autocomplete="off"></td>';   		
		htmlRows += '<td><input type="number" name="price[]" step=".01" id="price_'+count+'" class="form-control price" autocomplete="off"></td>';		 
		htmlRows += '<td><input type="number" name="total[]" id="total_'+count+'" class="form-control total" autocomplete="off" readonly></td>';          
		htmlRows += '<td><input  type="button" value="add" id="addRowsPerticular"/> </td>';          
		htmlRows += '</tr>';
   $('table > tbody > tr').eq(id).after(htmlRows);
   count++;
});
	
	$(document).on('click', '#removeRows', function(){
		$(".itemRow:checked").each(function() {
			$(this).closest('tr').remove();
		});
		$('#checkAll').prop('checked', false);
		calculateTotal();
	});		
	$(document).on('blur', "[id^=quantity_]", function(){
		calculateTotal();
	});	
	$(document).on('blur', "[id^=price_]", function(){
		calculateTotal();
	});	
	$(document).on('blur', "#taxRate", function(){		
		calculateTotal();
	});	
	$(document).on('blur', "#amountPaid", function(){
		var amountPaid = $(this).val();
		var totalAftertax = $('#totalAftertax').val();	
		if(amountPaid && totalAftertax) {
			totalAftertax = totalAftertax-amountPaid;			
			$('#amountDue').val(totalAftertax);
		} else {
			$('#amountDue').val(totalAftertax);
		}	
	});	
	$(document).on('click', '.deleteInvoice', function(){
		var id = $(this).attr("id");
	if(id != undefined){
		if(confirm("Are you sure you want to remove this?")){
			$.ajax({
				url:"action.php",
				method:"POST",
				dataType: "json",
				data:{id:id, action:'delete_invoice'},				
				success:function(response) {
					if(response.status == 1) {
						$('#'+id).closest("tr").remove();
					}
				}
			});
		} else {
			return false;
		}
	}else{
		if(confirm("Are you sure you want to remove All Invoice?")){
			$.ajax({
				url:"action.php",
				method:"POST",
				dataType: "json",
				data:{action:'delete_invoices'},				
				success:function(response) {
					if(response.status == 1) {
						refreshPage();
					}
				}
			});
		} else {
			return false;
		}
	}
	});
});
function refreshPage(){
	location.reload(true);
}	
function calculateTotal(){
	var totalAmount = 0; 
	$("[id^='price_']").each(function() {
		var id = $(this).attr('id');
		id = id.replace("price_",'');
		var price = $('#price_'+id).val();
		var quantity  = $('#quantity_'+id).val();
		if(!quantity) {
			quantity = 1;
		}
		var total = price*quantity;
		$('#total_'+id).val(parseFloat(total));
		totalAmount += total;			
	});
	$('#subTotal').val(parseFloat(totalAmount));	
	var taxRate = $("#taxRate").val();
	var subTotal = $('#subTotal').val();	
	if(subTotal) {
		var taxAmount = subTotal*taxRate/100;
		$('#taxAmount').val(taxAmount);
		subTotal = parseFloat(subTotal)+parseFloat(taxAmount);
		$('#totalAftertax').val(subTotal);		
		var amountPaid = $('#amountPaid').val();
		var totalAftertax = $('#totalAftertax').val();	
		if(amountPaid && totalAftertax) {
			totalAftertax = totalAftertax-amountPaid;			
			$('#amountDue').val(totalAftertax);
		} else {		
			$('#amountDue').val(subTotal);
		}
	}
}

 